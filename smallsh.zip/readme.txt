Tested on Ubuntu 20.04 and os1.engr.oregonstate.edu server

File Name -  smallsh.c
Compile -
gcc -o smallsh smallsh.c
Output - smallsh (binary)

Sample:
$ ./smallsh
: ls
junk  junk2  p3testscript  sample_cd_command  smallsh  smallsh.c  smallsh.zip
: status
exit value 0
: exit
Exiting smallsh

Usage with grading file
./p3testscript
